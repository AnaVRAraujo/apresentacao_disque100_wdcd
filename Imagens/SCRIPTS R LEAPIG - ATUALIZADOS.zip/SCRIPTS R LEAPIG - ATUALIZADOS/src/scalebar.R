# Uso Paraiba: scalebar(c(-38.5,-8.7), mapa = mapa)
# Uso Paraiba: scalebar(shape = "pb", mapa = mapa)
# Uso Joao Pessoa: scalebar(c(-35,-7.25), mapa = mapa)
# Uso Joao Pessoa: scalebar(shape="jp", mapa = mapa)

scalebar <- function(loc = NA,shape = "pb", unit="km",division.cex=.8, mapa=mapa) {
  
  if(any(is.na(loc))==T){
    if(shape=="pb"){
      #Para Paraíba (Localização)
      loc = c(-38.5,-8.7)
    }
    if(shape == "jp"){
      #Para João Pessoa (Localização)
      loc = c(-35,-7.25)
      
    }
  }
  
    if(missing(loc)) stop("loc is missing")
  maximo <- sapply(1:length(mapa), function(i){
    max(mapa[[i]][[1]][1][[1]][,1])
  })
  minimo <- sapply(1:length(mapa), function(i){
    min(mapa[[i]][[1]][1][[1]][,1])
  })
  length<-as.numeric(
    sprintf(
      "%0.2f", abs(abs(max(maximo))-abs(min(minimo)))/2
    )
  )
  x <- c(0,length/c(4,2,4/3,1),length*1.1)+loc[1]
  y <- c(0,length/(10*3:1))+loc[2]
  cols <- rep(c("black","white"),2)
  for (i in 1:4) rect(x[i],y[1],x[i+1],y[2],col=cols[i])
  for (i in 1:5) segments(x[i],y[2],x[i],y[3])
  labels <- x[c(1)]-loc[1]
  # labels<- append(labels, sprintf("%0f",length*111.12/2))
  # labels<- append(labels,paste(sprintf("%0f",length*111.12),unit))
  labels<- append(labels, round(length*111.12/2))
  labels<- append(labels,paste(round(length*111.12),unit))
  text(x[c(1,3,5)],y[4],labels=labels,adj=.5,cex=division.cex)
}
# A localidade da Escala ficou manual, colocá-la de acordo com as
# coordenadas do SHAPE.
