# ----  Executar no terminal - Ubuntu
sudo apt-get update
sudo apt-get install gdal-bin
sudo apt-get install libgdal-dev


# ----  Pacotes para ser instalados na primeira vez de utilizaçao
install.packages("spdep")
install.packages("DCluster")

# ---- Load library
library(spdep)
library(sf)
library(sp)
library(DCluster)
library(tibble)
source("src/scalebar.R")
source("src/rosadosventos.R")

# ----  Load shapefile
shapename <- read_sf('shape_estado_pb/Municipios.shp')
mapa <- shapename$geometry

# ---- Desenhar mapa coroplético com as classes e cores determinadas anteriormente
plot(mapa, border="black", axes=TRUE, las=1, xlab="Longitude", ylab="Latitude",forcefill=FALSE)

# ---- Rosa dos Ventos
compassRose(-35.2,-6, rot=0, cex=0.7)
# ---- Escala
scalebar (loc = c(-38.5,-8.5), mapa = mapa, division.cex=.8)

