# ----  Pacotes para ser instalados na primeira vez de utilizaçao
install.packages("spdep")
install.packages("DCluster")

# ---- Load library
library(spdep)
library(sf)
library(sp)
library(DCluster)
source("src/scalebar.R")
source("src/rosadosventos.R")

# ----  Load shapefile
shapename <- read_sf('shape_estado_pb/Municipios.shp')
mapa <- shapename$geometry

# ---- Carregar dados
dados <- read.csv2("dados/exemplo_de_base.csv")

# ---- Selecionando Coluna de casos
casos=dados$casos
pop=dados$POP2017

# ----  Criar banco de dados no fromato DCluster, denominado dadosT
dadosT = data.frame(Observed = 1*casos)
dadosT = cbind(dadosT, Expected = pop/sum(pop)*sum(casos)) 
dadosT = cbind(dadosT, Population = pop, x = dados$coordx, y = dados$coordy)
dadosT

# modificacao no m?todo de Besag e Newell
for( k in 2 : max(dadosT$Observed) ){
  bnresults = opgam(data=dadosT, thegrid=dadosT[,c("x","y")], alpha=.05, iscluster=bn.iscluster, k=k, R=100, model="poisson", mle=calculate.mle(dadosT))
  if(length(bnresults$x) != 0)
    break
}
bn_modificado = bnresults
for( k in k : max(dadosT$Observed) ){
  bnresults = opgam(data=dadosT, thegrid=dadosT[,c("x","y")], alpha=.05, iscluster=bn.iscluster, k=k, R=100, model="poisson", mle=calculate.mle(dadosT))
  if( min(bnresults$pvalue) < min(bn_modificado$pvalue) ){
    bn_modificado = bnresults
    k_usado = k
  }
}

# ---- Desenhar mapa com centroides dos municipios, destacando os significativos em preto
plot(mapa, border ="black", axes = TRUE, col="#FFDEAD")
#plot(mapa, border ="black", axes = TRUE, col="white")
points(dadosT$x, dadosT$y)
points(bn_modificado$x, bn_modificado$y, col = '#FF0000', pch = 19)

# ---- Rosa dos Ventos
compassRose(-35.2,-6, rot=0, cex=0.7)
# ---- Escala
scalebar (loc = c(-38.5,-8.5), mapa = mapa, division.cex=.8)

