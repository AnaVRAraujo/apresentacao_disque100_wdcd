# ----  Pacotes para ser instalados na primeira vez de utilizaçao
install.packages("spdep")
install.packages("DCluster")

# ---- Load library
library(spdep)
library(sf)
library(sp)
library(DCluster)
library(tibble)
source("src/scalebar.R")
source("src/rosadosventos.R")

# ----  Load shapefile
shapename <- read_sf('shape_estado_pb/Municipios.shp')
mapa <- shapename$geometry

# ---- Carregar dados
dados <- read.csv2("dados/exemplo_de_base.csv")

# ---- Selecionando Coluna de casos
casos=dados$casos
pop=dados$POP2017

# ----  Criar banco de dados no fromato DCluster, denominado dadosT
dadosT = data.frame(Population = pop, x = dados$coordx, y = dados$coordy)
dadosT = cbind(dadosT, CasosPop = casos/pop) 
dadosT = cbind(dadosT, RIE = dadosT$CasosPop/(sum(casos)/sum(pop))) 
dadosT

# ---- Selecionar coluna de variaveis para gerar mapa
var = dadosT$RIE

# ---- Criar intervalo de classes
classes = c(-Inf, 0.00000000001, 0.49999999999, 0.99999999999, 1.49999999999, 1.99999999999, Inf)

# ---- Criar legenda
legenda = c('0','0,0--0,5','0,5|--1,0','1,0|--1,5','1,5|--2,0','2,0 ou +')  #RIE PB

# ---- Definir as cores para as classes (máximo sete)
cores = c("#ffffff","#f1f1d1","#e9e57f","#cda300","#a46500","#593216")  #RIEPb

# ---- Desenhar mapa coroplético com as classes e cores determinadas anteriormente
plot(mapa, border="black", axes=TRUE, las=1, xlab="Longitude", ylab="Latitude", col=cores[findInterval(var, classes, all.inside=TRUE)], forcefill=FALSE)

# ---- Rosa dos Ventos
compassRose(-35.2,-6, rot=0, cex=0.7)
# ---- Escala
scalebar (loc = c(-38.5,-8.5), mapa = mapa, division.cex=.8)

